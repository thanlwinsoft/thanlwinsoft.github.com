Keyboard files for typing Myanmar Unicode with Keyman/KMFL 

Keyboards:

my-Win
Myanmar Unicode keyboard similar to the traditional Win layout - see KeyboardMyWin.pdf for layout details.

my-Ava
Myanmar Unicode keyboard similar to the Ava Laser font from John Okell - see KeyboardMyWin.pdf for layout details. This layout attempts to be phonetic with the English letters.

Installation:

Windows

Make sure you have Keyman >=6 installed from Tavultesoft http://www.tavultesoft.com/keyman/
Double click on the kmx files to install.

Linux

Install SCIM and KMFL - see http://kmfl.sourceforge.net/ for details.
Create a directory ~/.scim/kmfl and copy the *.kmfl files and icons/ directory into it.
e.g. if you unziped the files in the current directory:

mkdir -p ~/.scim/kmfl
cp *.kmfl ~/.scim/kmfl
cp -r icons ~/.scim/kmfl

(Note: this only installs the files for the current user)
