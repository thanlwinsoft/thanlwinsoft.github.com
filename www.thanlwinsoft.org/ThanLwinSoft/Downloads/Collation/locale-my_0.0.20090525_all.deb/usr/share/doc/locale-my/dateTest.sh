export LANG=my_MM.UTF-8
export LANGUAGE=my_MM:en_GB:en

rm dates.txt
date --date='TZ="Asia/Rangoon" 2006-01-01 06:30' "+%B %b" >> dates.txt
date --date='TZ="Asia/Rangoon" 2006-02-01 06:30' "+%B %b" >> dates.txt
date --date='TZ="Asia/Rangoon" 2006-03-01 06:30' "+%B %b" >> dates.txt
date --date='TZ="Asia/Rangoon" 2006-04-01 06:30' "+%B %b" >> dates.txt
date --date='TZ="Asia/Rangoon" 2006-05-01 06:30' "+%B %b" >> dates.txt
date --date='TZ="Asia/Rangoon" 2006-06-01 06:30' "+%B %b" >> dates.txt
date --date='TZ="Asia/Rangoon" 2006-07-01 06:30' "+%B %b" >> dates.txt
date --date='TZ="Asia/Rangoon" 2006-08-01 06:30' "+%B %b" >> dates.txt
date --date='TZ="Asia/Rangoon" 2006-09-01 06:30' "+%B %b" >> dates.txt
date --date='TZ="Asia/Rangoon" 2006-10-01 06:30' "+%B %b" >> dates.txt
date --date='TZ="Asia/Rangoon" 2006-11-01 06:30' "+%B %b" >> dates.txt
date --date='TZ="Asia/Rangoon" 2006-12-01 06:30' "+%B %b" >> dates.txt
 
date --date='TZ="Asia/Rangoon" 2006-01-01 06:30' "+%A %a" >> dates.txt
date --date='TZ="Asia/Rangoon" 2006-01-02 06:30' "+%A %a" >> dates.txt
date --date='TZ="Asia/Rangoon" 2006-01-03 06:30' "+%A %a" >> dates.txt
date --date='TZ="Asia/Rangoon" 2006-01-04 06:30' "+%A %a" >> dates.txt
date --date='TZ="Asia/Rangoon" 2006-01-05 06:30' "+%A %a" >> dates.txt
date --date='TZ="Asia/Rangoon" 2006-01-06 06:30' "+%A %a" >> dates.txt
date --date='TZ="Asia/Rangoon" 2006-01-07 06:30' "+%A %a" >> dates.txt
sort WordList.txt > WordListSorted.txt
sort MyanmarCodes.txt > MyanmarCodesSorted.txt
#gedit dates.txt &
#gedit WordListSorted.txt &
sort consonants.txt > consonantsSorted.txt
sort medials.txt > medialsSorted.txt
sort vowels.txt > vowelsSorted.txt
sort tones.txt > tonesSorted.txt
sort multiSyllable.txt > multiSyllableSorted.txt
sort AVowelOrder.txt > AVowelOrderSorted.txt
sort Headwords.txt > HeadwordsSorted.txt

