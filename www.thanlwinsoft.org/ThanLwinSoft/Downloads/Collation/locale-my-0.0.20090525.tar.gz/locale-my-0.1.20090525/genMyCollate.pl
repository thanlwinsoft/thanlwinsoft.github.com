#!/usr/bin/perl -w
# Copyright 2004,2006,2007 Keith Stribley <http://www.thanlwinsoft.org/>
#
# This file is free software; you can redistribute it and/or
#   modify it under the terms of the GNU Lesser General Public
#   License as published by the Free Software Foundation; either
#   version 2.1 of the License, or (at your option) any later version.
#
# Script to create LC_COLLATE section for Myanmar locale
#
# This collation implements Myanmar Spelling Book Order.
# Note: Pali order would be much easier to implement, but
# is no longer used. 
# This collation is very inefficent because it uses
# a huge number of collating elements to get the right
# sort order 
# This is the only way that I can see of doing it within the 
# limitations of the locale file format. However, if you know
# a better way please let me know.
# As a result it needs a specially built localdef with
# an increased maximum element size.
# glibc-2.4 no longer seems to need this change
#
# You may need to change ld-collate.c to specify a higher argument 
# in the MIN function around line 2479 of
# glibc-2.3.3/locale/programs/ld-collate.c 
# e.g.
#
# elem_size = MIN(next_prime (elem_size * 1.4), 1361);
#
# (original only 257) or just completely remove the limit
# (but that might be dangerous):
#
# elem_size = next_prime (elem_size * 1.4);
#
# This collation follows the proposed changes to unicode
# this may require a modified version /usr/share/i18n/charmaps/UTF-8.gz
# which includes the new characters.

local $vowels;
local $tones;
local $yrwh;

#$LAST_CONSONANT = 33;

# Myanmar sorting is done by clusters
# The sorting order is:
# 1. Base consonant
# 2. YRWH medials
# 3. killed consonant
# 4. vowel
# 5. tone
# Most of these are easy because the sorting order is the same as the 
# storage order for 1,2 and 5. However, 4 is stored before 3 so all
# permutations of 3 and 4 need to be defined as collating elements
# and listed between 2 and 5.
# However, YRWH medials are prevented from matching by the killed 
# consonants so need to combine 1 and 2 as well.
#
# The code points for Mon, Karen, Kayah, Shan are also included, 
# though only at a basic character level. 
# More information is needed to provide correct sorting for these languages. 
# Indeed, they may need their own locales.

#medials
@yrwh = (
"",
"<U105E>",#mon na
"<U105F>",#mon ma
"<U103B>",#ya
"<U103C>",#ra
"<U1060>",#mon la
"<U103D>",#wa
"<U1082>",#shan wa
"<U103E>",#ha
"<U103B><U103D>",#ya,wa
"<U103C><U103D>",#ra,wa
"<U103B><U103E>",#ya,ha
"<U103C><U103E>",#ra,ha
"<U103D><U103E>",#wa,ha
"<U103B><U103D><U103E>",#ya,wa,ha
"<U103C><U103D><U103E>",#ra,wa,ha
);

@vowels = (
"",
#"<U102B>",#tall aa
"<U102C>",#aa
"<U1083>",#shan aa
"<U1072>",#kayah oe
"<U102D>",#i
"<U1071>",#Geba Karen i
"<U102E>",#ii
"<U1062>",#Sgaw eu
"<U1067>",#w pwo eu
"<U1068>",#w pwo ue
"<U1033>",#mon ii
"<U102F>",#u
"<U1073>",#kayah u
"<U1074>",#kayah ee
"<U1030>",#uu
"<U1056>",#vocalic r
"<U1057>",#vocalic rr
"<U1058>",#vocalic l 
"<U1059>",#vocalic ll
"<U1031>",#e
"<U1035>",# e above
"<U1084>",#shan e
"<U1085>",# shan e above
"<U1032>",#ai
#"<U1031><U102B>",#tall aw High tone
"<U1031><U102C>",# aw High tone
#"<U1031><U102B><U103A>",#aw tall low tone
"<U1031><U102C><U103A>",#aw low tone
"<U1034>",#mon o
"<U1036>",# an
"<U102D><U102F>",#o
"<U1063>",#Sgaw Hathi
"<U1086>"#shan final y
);

%equivalentVowels = (
    "<U102C>" , ["<U102B>"],
    "<U1031><U102C>" , ["<U1031><U102B>"],
    "<U1031><U102C><U103A>" , ["<U1031><U102B><U103A>"]
);



# these are only used with finals to reorder final/vowel priority
@myVowels = (
"",
#"<U102B>",#1
"<U102C>",#2
"<U102D>",#3
"<U102E>",#4
"<U102F>",#5
"<U1030>",#6
"<U1031>",#7
"<U1032>",#8
#"<U1031><U102B>",#9 High tone
"<U1031><U102C>",#10 High tone
"<U1036>",#13
"<U102D><U102F>"#14
);

@consonants = (
("<U1000>","<U1075>"),#KA,shan
("<U1001>","<U1076>"),#KHA,shan
("<U1002>","<U1077>"),#GA,shan ga
"<U1003>",#GHA
("<U1004>","<U105A>"),#NGA,mon
("<U1005>","<U1078>"),#CA,shan
"<U1006>",#CHA
("<U1007>","<U1079>"),#JA,shan-za
("<U1008>","<U105B>","<U1061>"),#JHA,mon,sgaw
("<U1009>","<U107A>"),#NYA,shan
"<U100A>",#NNYA
"<U100B>",#TTA
"<U100C>",#TTHA
"<U100D>",#DDA
"<U100E>",#DDHA
("<U100F>","<U106E>"),#NNA,e-pwo
"<U1010>",#TA
"<U1011>",#THA
("<U1012>","<U107B>"),#DA,shan-da
"<U1013>",#DHA
("<U1014>","<U107C>"),#NA,shan
"<U1015>",#PA
("<U1016>","<U107D>","<U107E>","<U108E>"),#PHA,shan,shan-fa,palaung-fa
("<U1017>","<U107F>"),#BA,shan-ba
"<U1018>",#BHA
"<U1019>",#MA
"<U101A>",#YA
"<U101B>",#RA
"<U101C>",#LA
"<U101D>",#WA
("<U1080>","<U1050>","<U1051>","<U1065>","<U101E>"),#shan-tha,SHA,SSA,w-pwo-tha,SA,
("<U101F>","<U1081>"),#HA,shan
("<U1020>","<U105C>","<U105D>","<U106F>","<U1070>","<U1066>"),#LLA,mon-bba,mon bbe,e-pwo-ywa,e-pwo-ghwa,w pwo pwa
("<U1021>"),
"<U1022>",#shan a
#"<U1028>",#mon e
"<U1052>",#vocalic r
"<U1053>",#vocalic rr
"<U1054>",#vocalic l 
"<U1055>",#vocalic ll

#"<U107F>","<U1072>"),#A,shan-aa,kayah-oe
#"<U1023>",#I
#"<U1024>",#II
#("<U1025>","<U1073>","<U1074>"),#U,kayah-u,kayah-ee
#("<U1026>","<U1052>","<U1053>","<U1054>","<U1055>"),#UU,vocalic-r,rr,l,ll
#("<U1027>","<U105D>","<U1066>","<U1028>"),#E,mon-bbe,w-pwo-pwa,mon-e
#"<U1029>",#O
#"<U102A>"#AU
);

@killed = (
"<U1000>",#0
"<U1001>",#1
"<U1002>",#2
"<U1003>",#3
"<U1004>",#4
"<U1005>",#5
"<U1006>",#6
"<U1007>",#7
"<U1009>",#8
"<U100A>",#9
"<U100B>",#10
"<U100C>",#11
"<U100D>",#12
"<U100E>",#13
"<U100F>",#14
"<U1010>",#15
"<U1011>",#16
"<U1012>",#17
"<U1013>",#18
"<U1014>",#19
"<U1015>",#20
"<U1016>",#21
"<U1017>",#22
"<U1018>",#23
"<U1019>",#24
"<U101A>",#25
"<U101B>",#26
"<U101C>",#27
"<U101D>",#28
"<U101E>",#29
"<U101F>",#30
"<U1020>"
);
# index of important killed characters with alternative forms
#$ngk = 4;
#$mak = 24;
#$sak = 29;


@tones = (
"",
"<U1069>",#w-pwo-1
"<U1037>",#dot-below
"<U1087>",#shan-2
"<U108B>",#shan-council-2
"<U106A>",#w-pwo-2
"<U1062><U103A>",#sgaw karen
"<U1088>",#shan-3
"<U108C>",#shan-council-3
"<U106B>",#w-pwo-3
"<U106C>",#w-pwo-4
"<U106D>",#w-pwo-5
"<U1069><U1037>",#w-pwo-1+1037
"<U106B><U1037>",#w-pwo-3+1037
"<U106A><U1037>",#w-pwo-2+1037
"<U102C><U103A>",#sgaw karen
"<U1038>",#visarga
"<U1037><U1038>",#myanmar
"<U1089>",#shan-5
"<U1063><U103A>",#sgaw karen
"<U108A>",#shan-6
"<U108D>",#shan-council-emphatic
"<U108F>",#paluang tone 6
"<U1064>"#sgaw karen
);

# start file
print "% --- This section is generated from a perl script do not modify by hand!\n";
print "LC_COLLATE\n";


# define collating elements

# medials
for ($y = 1; $y<=$#yrwh; $y++)
{
    $med = $yrwh[$y];
    $med =~ s/[<U>]//g;
    printf("collating-element <MMYRWH%s> from \"%s\"\n",$med,$yrwh[$y]);
}

# vowels with killed consonant
for ($m = 0; $m<=$#killed; $m++) # loop over final consonants
{
    $killer = $killed[$m];
    $killer =~ s/[<>U]//g;
     for ($v = 1; $v<=$#myVowels; $v++)
     {
         $vowel = $myVowels[$v];
         $vowel =~ s/[<>U]//g;
         #if ($v != $awVowel && $v != $awVowelTall)
         {
            printf("collating-element <MMV%sK%sA> from \"%s%s<U103A>\"\n",
                $vowel,$killer,$myVowels[$v],$killed[$m]);
            if (exists($equivalentVowels{$myVowels[$v]}))
            {
                $equiv = $equivalentVowels{$myVowels[$v]};
                for ($i = 0; $i <= $#{$equiv}; $i++)
                {
                    printf("collating-element <MMV%sALT%dK%sA> from \"%s%s<U103A>\"\n", 
                            $vowel, $i, $killer, $equiv->[$i],$killed[$m]);
                }
            }
            if ($killed[$m] eq "<U1019>" && ($vowel eq "102F" || $vowel eq "102D"))
            {
            	printf("collating-element <MMV%sK10191037A> from \"%s<U1019><U1037><U103A>\"\n", $vowel, $myVowels[$v]);
            	printf("collating-element <MMV%sK10191037A2> from \"%s<U1019><U103A><U1037>\"\n", $vowel, $myVowels[$v]);
            	printf("collating-element <MMV%sK10191038A> from \"%s<U1019><U103A><U1038>\"\n", $vowel, $myVowels[$v]);
            }
            if ($killed[$m] eq "<U1004>")
            {
                #kinzi
                printf("collating-element <MMV%sK%sB> from \"%s%s<U103A><U1039>\"\n",
                $vowel,$killer,$myVowels[$v],$killed[$m]);
                if (exists($equivalentVowels{$myVowels[$v]}))
                {
                    $equiv = $equivalentVowels{$myVowels[$v]};
                    for ($i = 0; $i <= $#{$equiv}; $i++)
                    {
                        printf("collating-element <MMV%sALT%dK%sB> from \"%s%s<U103A><U1039>\"\n", 
                                $vowel, $i, $killer, $equiv->[$i],$killed[$m]);
                    }
                }
            }
            else
            {
                printf("collating-element <MMV%sK%sB> from \"%s%s<U1039>\"\n",
                        $vowel,$killer,$myVowels[$v],$killed[$m]);
                if (exists($equivalentVowels{$myVowels[$v]}))
                {
                    $equiv = $equivalentVowels{$myVowels[$v]};
                    for ($i = 0; $i <= $#{$equiv}; $i++)
                    {
                        printf("collating-element <MMV%sALT%dK%sB> from \"%s%s<U1039>\"\n", 
                                $vowel, $i, $killer, $equiv->[$i],$killed[$m]);
                    }
                }
                if ($killed[$m] eq "<U101E>") # sa
                {
                    printf("collating-element <MMV%sK%sC> from \"%s<U103F>\"\n",
                            $vowel,$killer,$myVowels[$v]);
                }
            }
         }
     }
}

# U1019/upper dot equivalence
printf("collating-element <MMV102DK1019C> from \"<U102D><U1036>\"\n");#i
printf("collating-element <MMV102DK10191037C> from \"<U102D><U1036><U1037>\"\n");#i
printf("collating-element <MMV102DK10191038C> from \"<U102D><U1036><U1038>\"\n");#i
printf("collating-element <MMV102FK1019C> from \"<U102F><U1036>\"\n");#u
printf("collating-element <MMV102FK10191037C> from \"<U102F><U1036><U1037>\"\n");#u
printf("collating-element <MMV102FK10191038C> from \"<U102F><U1036><U1038>\"\n");#u
#printf("collating-element <MMC1021V102FK1036> from \"<U1021><U102F><U1036>\"\n");

# killed consonants with no vowel
for ($m = 0; $m<=$#killed; $m++) # loop over final consonants
{
    $killer = $killed[$m];
    $killer =~ s/[<>U]//g;
    printf("collating-element <MMK%sA> from \"%s<U1039>\"\n",
            $killer,$killed[$m]);
    printf("collating-element <MMK%sB> from \"%s<U103A>\"\n",
            $killer,$killed[$m]);
}

# vowels with no killed consonant
for ($v = 1; $v<=$#vowels; $v++)
{
    $vowel = $vowels[$v];
    $vowel =~ s/[<>U]//g;
    printf("collating-element <MMV%s> from \"%s\"\n", $vowel, $vowels[$v]);
    if (exists($equivalentVowels{$vowels[$v]}))
    {
        $equiv = $equivalentVowels{$vowels[$v]};
        for ($i = 0; $i <= $#{$equiv}; $i++)
        {
            #print STDERR "Equiv" . $equiv->[$i] . "\n";
            printf("collating-element <MMV%sALT%d> from \"%s\"\n", $vowel, $i, $equiv->[$i]);
        }
    }
}

# tones
for ($t = 1; $t<=$#tones; $t++)
{
    $tone = $tones[$t];
    $tone =~ s/[<>U]//g;
    printf("collating-element <MMT%s> from \"%s\"\n",$tone,$tones[$t]);
}

# misc collating elements for independent vowels and rare words 
print << 'EOT';
collating-element <I1023K1005A> from "<U1023><U1005><U1039>"%K5
collating-element <I1023K1005B> from "<U1023><U1005><U103A>"%K5
collating-element <I1023K100BA> from "<U1023><U100B><U1039>"%K5
collating-element <I1023K100BB> from "<U1023><U100B><U103A>"%K5
collating-element <I1023K1010A> from "<U1023><U1010><U1039>"%K15
collating-element <I1023K1010B> from "<U1023><U1010><U103A>"%K15
collating-element <I1023K1012A> from "<U1023><U1012><U1039>"%K17
collating-element <I1023K1012B> from "<U1023><U1012><U103A>"%K17
collating-element <I1023K1014A> from "<U1023><U1014><U1039>"%K19
collating-element <I1023K1014B> from "<U1023><U1014><U103A>"%K19
collating-element <I1023K1019A> from "<U1023><U1019><U1039>"%K24
collating-element <I1023K1019B> from "<U1023><U1019><U103A>"%K24
collating-element <I1023K101EA> from "<U1023><U101E><U1039>"%K24
collating-element <I1023K101EB> from "<U1023><U101E><U103A>"%K24
collating-element <I1023K101E> from "<U1023><U103F>"%K29
collating-element <I1025K1000A> from "<U1025><U1000><U1039>"%K0
collating-element <I1025K1000B> from "<U1025><U1000><U103A>"%K0
collating-element <I1025K1005A> from "<U1025><U1005><U1039>"%K5
collating-element <I1025K1005B> from "<U1025><U1005><U103A>"%K5
collating-element <I1025K100AA> from "<U1025><U100A><U1039>"%K9
collating-element <I1025K100AB> from "<U1025><U100A><U103A>"%K9
collating-element <I1025K100FA> from "<U1025><U100F><U1039>"%K14
collating-element <I1025K100FB> from "<U1025><U100F><U103A>"%K14
collating-element <I1025K1010A> from "<U1025><U1010><U1039>"%K15
collating-element <I1025K1010B> from "<U1025><U1010><U103A>"%K15
collating-element <I1025K1012A> from "<U1025><U1012><U1039>"%
collating-element <I1025K1012B> from "<U1025><U1012><U103A>"%
collating-element <I1025K1014A> from "<U1025><U1014><U1039>"%K15
collating-element <I1025K1014B> from "<U1025><U1014><U103A>"%K15
collating-element <I1025K1015A> from "<U1025><U1015><U1039>"%K15
collating-element <I1025K1015B> from "<U1025><U1015><U103A>"%K15
collating-element <I1025K1019A> from "<U1025><U1019><U1039>"%K24
collating-element <I1025K1019B> from "<U1025><U1019><U103A>"%K24
collating-element <I1025K1036> from "<U1025><U102F><U1036>"%K24
collating-element <I1025K101E> from "<U1025><U103F>"%K29
collating-element <I1025K101EA> from "<U1025><U101E><U1039>"%K29
collating-element <I1025K101EB> from "<U1025><U101E><U103A>"%K29
collating-element <I1027K100AA> from "<U1027><U100A><U1039>"%K9
collating-element <I1027K100AB> from "<U1027><U100A><U103A>"%K9
collating-element <I1029K100BA> from "<U1029><U100B><U1039>"%
collating-element <I1029K100BB> from "<U1029><U100B><U103A>"%
collating-element <I1029K1010A> from "<U1029><U1010><U1039>"%
collating-element <I1029K1010B> from "<U1029><U1010><U103A>"%
collating-element <I10291031102CK1004A> from "<U1029><U1031><U102C><U1004><U1039>"%
collating-element <I10291031102CK1004B> from "<U1029><U1031><U102C><U1004><U103A>"%

collating-element <Man> from "<U101A><U1031><U102C><U1000><U103A><U103B><U102C><U1038>"
collating-element <FirstPerson> from "<U1000><U103B><U103D><U1014><U103A><U102F><U1015><U103A>"
collating-element <RightPali> from "<U101C><U1000><U103A><U103B><U102C>"
collating-element <Daughter> from "<U101E><U1039><U1019><U102E>" %variant spelling
collating-element <Rice> from "<U1011><U1039><U1019><U1004><U103A><U1038>" %variant spelling
collating-element <Tea> from "<U101C><U1039><U1018><U1000><U103A>" %variant spelling
EOT

# define collating symbols
#for ($c = 0; $c<=$LAST_CONSONANT; $c++)
#{
#    printf("collating-symbol <CSMMC%02d>\n",$c);
#}
for ($c = 0; $c <= $#consonants; $c++)
{
    $cons = $consonants[$c];
    $cons =~ s/[<U>]//g;
    printf("collating-symbol <CSMMC%s>\n",$cons);
}

# Myanmar symbols
for ($s = 1; $s<=4; $s++)
{
    printf("collating-symbol <CSMMS%02d>\n",$s);
}

# medials
for ($y = 1; $y<=$#yrwh; $y++)
{
    $med = $yrwh[$y];
    $med =~ s/[<U>]//g;
    printf("collating-symbol <CSMMYRWH%s>\n",$med);
}

# killed consonant symbols
for ($k = 0; $k<=$#killed; $k++)
{
    $killer = $killed[$k];
    $killer =~ s/[<>U]//g;
    printf("collating-symbol <CSMMCK%s>\n",$killer);
    if ($killed[$k] eq "<U1019>")
    {
        printf("collating-symbol <CSMMCK102D1019>\n");
        printf("collating-symbol <CSMMCK102D1036>\n");
        printf("collating-symbol <CSMMCK102D10191037>\n");
        printf("collating-symbol <CSMMCK102D10361037>\n");
        printf("collating-symbol <CSMMCK102D10191038>\n");
        printf("collating-symbol <CSMMCK102D10361038>\n");
        printf("collating-symbol <CSMMCK102F1019>\n");
        printf("collating-symbol <CSMMCK102F1036>\n");
        printf("collating-symbol <CSMMCK102F10191037>\n");
        printf("collating-symbol <CSMMCK102F10361037>\n");
        printf("collating-symbol <CSMMCK102F10191038>\n");
        printf("collating-symbol <CSMMCK102F10361038>\n");
    }
}

# vowels symbols 
for ($v = 0; $v<=$#vowels; $v++)
{
    $vowel = $vowels[$v];
    $vowel =~ s/[<>U]//g;
    printf("collating-symbol <CSMMV%s>\n",$vowel);
}

# tones
for ($t = 1; $t<=$#tones; $t++)
{
    $tone = $tones[$t];
    $tone =~ s/[<>U]//g;
    printf("collating-symbol <CSMMT%s>\n",$tone);
}



# output section
print << 'EOT';
collating-symbol  <BLANK>
collating-symbol  <MYANMAR>
collating-symbol  <SHAN>
collating-symbol  <MON>
collating-symbol  <MYIV>
collating-symbol  <CAP>
collating-symbol  <MIN>
collating-symbol  <ALT>
collating-symbol  <KILLED>
collating-symbol  <STACK>
% digits
collating-symbol <0>
collating-symbol <1>
collating-symbol <2>
collating-symbol <3>
collating-symbol <4>
collating-symbol <5>
collating-symbol <6>
collating-symbol <7>
collating-symbol <8>
collating-symbol <9>
% letters
collating-symbol <a>
collating-symbol <b>
collating-symbol <c>
collating-symbol <d>
collating-symbol <e>
collating-symbol <f>
collating-symbol <g>
collating-symbol <h>
collating-symbol <i>
collating-symbol <j>
collating-symbol <k>
collating-symbol <l>
collating-symbol <m>
collating-symbol <n>
collating-symbol <o>
collating-symbol <p>
collating-symbol <q>
collating-symbol <r>
collating-symbol <s>
collating-symbol <t>
collating-symbol <u>
collating-symbol <v>
collating-symbol <w>
collating-symbol <x>
collating-symbol <y>
collating-symbol <z>
<BLANK>
<MYANMAR>
<SHAN>
<MON>
<MYIV>
<CAP>
<MIN>
<ALT>
<KILLED>
<STACK>

% digits
<0> % 48
<1> % 49
<2> % 50
<3> % 51
<4> % 52
<5> % 53
<6> % 54
<7> % 55
<8> % 56
<9> % 57
% letters
<a> % 97
<b> % 98
<c> % 99
<d> % 100
<e> % 101
<f> % 102
<g> % 103
<h> % 104
<i> % 105
<j> % 106
<k> % 107
<l> % 108
<m> % 109
<n> % 110
<o> % 111
<p> % 112
<q> % 113
<r> % 114
<s> % 115
<t> % 116
<u> % 117
<v> % 118
<w> % 119
<x> % 120
<y> % 121
<z> % 122

EOT

# define order

#for ($c = 0; $c<=$LAST_CONSONANT; $c++)
#{
#    printf("<CSMMC%02d>\n",$c);
#}
for ($c = 0; $c <= $#consonants; $c++)
{
    $cons = $consonants[$c];
    $cons =~ s/[<U>]//g;
    printf("<CSMMC%s>\n",$cons);
}

for ($s = 1; $s<=4; $s++) # for Myanmar symbols
{
    printf("<CSMMS%02d>\n",$s);
}

for ($t = 1; $t<=$#tones; $t++)
{
    $tone = $tones[$t];
    $tone =~ s/[<>U]//g;
    printf("<CSMMT%s>\n",$tone);
}


# vowels symbols 
for ($v = 0; $v<=$#vowels; $v++)
{
    $vowel = $vowels[$v];
    $vowel =~ s/[<>U]//g;
    printf("<CSMMV%s>\n",$vowel);
}

# killed consonants
for ($k = 0; $k<=$#killed; $k++)
{
    $killer = $killed[$k];
    $killer =~ s/[<>U]//g;
    printf("<CSMMCK%s>\n",$killer);
    if ($killed[$k] eq "<U1019>")
    {
    	printf("<CSMMCK102D1019>\n");
    	printf("<CSMMCK102D1036>\n");
    	printf("<CSMMCK102D10191037>\n");
        printf("<CSMMCK102D10361037>\n");
        printf("<CSMMCK102D10191038>\n");
        printf("<CSMMCK102D10361038>\n");
        printf("<CSMMCK102F1019>\n");
        printf("<CSMMCK102F1036>\n");
    	printf("<CSMMCK102F10191037>\n");
        printf("<CSMMCK102F10361037>\n");
        printf("<CSMMCK102F10191038>\n");
        printf("<CSMMCK102F10361038>\n");
    }
}

# medials
for ($y = 1; $y<=$#yrwh; $y++)
{
    $med = $yrwh[$y];
    $med =~ s/[<U>]//g;
    printf("<CSMMYRWH%s>\n",$med);
}

print "order_start forward;forward;forward;forward\n";
print "UNDEFINED      IGNORE;IGNORE;IGNORE;IGNORE\n";

# the first bit is based on what the Thai's do
print <<'EOT';
% punctuation marks, ordered after ISO/IEC 14651
<U0020>   IGNORE;IGNORE;<U0020>;IGNORE          % SPACE
<U005F>   IGNORE;IGNORE;<U005F>;IGNORE     % LOW LINE
<U002D>   IGNORE;IGNORE;<U002D>;IGNORE         % HYPHEN-MINUS
<U002C>   IGNORE;IGNORE;<U002C>;IGNORE          % COMMA
<U003B>   IGNORE;IGNORE;<U003B>;IGNORE      % SEMICOLON
<U104A>   IGNORE;IGNORE;<U104A>;IGNORE          % MYANMAR SIGN LITTLE SECTION
<U003A>   IGNORE;IGNORE;<U003A>;IGNORE          % COLON
<U0021>   IGNORE;IGNORE;<U0021>;IGNORE  % EXCLAMATION MARK
<U003F>   IGNORE;IGNORE;<U003F>;IGNORE     % QUESTION MARK
<U002F>   IGNORE;IGNORE;<U002F>;IGNORE          % SOLIDUS
<U002E>   IGNORE;IGNORE;<U002E>;IGNORE         % FULL STOP
<U104B>   IGNORE;IGNORE;<U104B>;IGNORE          % MYANMAR SIGN SECTION
<U0060>   IGNORE;IGNORE;<U0060>;IGNORE   % GRAVE ACCENT
<U005E>   IGNORE;IGNORE;<U005E>;IGNORE     % CIRCUMFLEX
<U007E>   IGNORE;IGNORE;<U007E>;IGNORE          % TILDE
<U0027>   IGNORE;IGNORE;<U0027>;IGNORE    % APOSTROPHE
<U0022>   IGNORE;IGNORE;<U0022>;IGNORE    % QUOTATION MARK
<U0028>   IGNORE;IGNORE;<U0028>;IGNORE  % LEFT PAREN.
<U005B>   IGNORE;IGNORE;<U005B>;IGNORE  % LT BRACKET
<U007B>   IGNORE;IGNORE;<U007B>;IGNORE    % LEFT CURLY BRACKET
<U007D>   IGNORE;IGNORE;<U007D>;IGNORE   % RIGHT CURLY BRACKET
<U005D>   IGNORE;IGNORE;<U005D>;IGNORE % RT BRACKET
<U0029>   IGNORE;IGNORE;<U0029>;IGNORE % RIGHT PAREN.
<U0040>   IGNORE;IGNORE;<U0040>;IGNORE     % COMMERCIAL AT
<U0024>   IGNORE;IGNORE;<U0024>;IGNORE   % DOLLAR SIGN
<U002A>   IGNORE;IGNORE;<U002A>;IGNORE      % ASTERISK
<U005C>   IGNORE;IGNORE;<U005C>;IGNORE     % BACK SOLIDUS
<U0026>   IGNORE;IGNORE;<U0026>;IGNORE     % AMPERSAND
<U0023>   IGNORE;IGNORE;<U0023>;IGNORE   % NUMBER SIGN
<U0025>   IGNORE;IGNORE;<U0025>;IGNORE  % PERCENT
<U002B>   IGNORE;IGNORE;<U002B>;IGNORE     % PLUS
<U003C>   IGNORE;IGNORE;<U003C>;IGNORE     % LESS THAN
<U003D>   IGNORE;IGNORE;<U003D>;IGNORE   % EQUAL
<U003E>   IGNORE;IGNORE;<U003E>;IGNORE  % GREATER THAN
<U007C>   IGNORE;IGNORE;<U007C>;IGNORE % VERTICAL LINE

% Arabic and Myanmar decimal digits
<U0030> <0>;<BLANK>;<BLANK>;<BLANK>   % DIGIT ZERO
<U1040> <0>;<MYANMAR>;<BLANK>;<BLANK>   % Myanmar DIGIT ZERO
<U1090> <0>;<SHAN>;<BLANK>;<BLANK>   % Shan DIGIT ZERO
<U0031> <1>;<BLANK>;<BLANK>;<BLANK>   % DIGIT ONE
<U1041> <1>;<MYANMAR>;<BLANK>;<BLANK>   % Myanmar DIGIT ONE
<U1091> <0>;<SHAN>;<BLANK>;<BLANK>   % Shan DIGIT ONE
<U0032> <2>;<BLANK>;<BLANK>;<BLANK>   % DIGIT TWO
<U1042> <2>;<MYANMAR>;<BLANK>;<BLANK>   % Myanmar DIGIT TWO
<U1092> <0>;<SHAN>;<BLANK>;<BLANK>   % Shan DIGIT TWO
<U0033> <3>;<BLANK>;<BLANK>;<BLANK>   % DIGIT THREE
<U1043> <3>;<MYANMAR>;<BLANK>;<BLANK>   % Myanmar DIGIT THREE
<U1093> <0>;<SHAN>;<BLANK>;<BLANK>   % Shan DIGIT THREE
<U0034> <4>;<BLANK>;<BLANK>;<BLANK>   % DIGIT FOUR
<U1044> <4>;<MYANMAR>;<BLANK>;<BLANK>   % Myanmar DIGIT FOUR
<U1094> <0>;<SHAN>;<BLANK>;<BLANK>   % Shan DIGIT FOUR
<U0035> <5>;<BLANK>;<BLANK>;<BLANK>   % DIGIT FIVE
<U1045> <5>;<MYANMAR>;<BLANK>;<BLANK>   % Myanmar DIGIT FIVE
<U1095> <0>;<SHAN>;<BLANK>;<BLANK>   % Shan DIGIT FIVE
<U0036> <6>;<BLANK>;<BLANK>;<BLANK>   % DIGIT SIX
<U1046> <6>;<MYANMAR>;<BLANK>;<BLANK>   % Myanmar DIGIT SIX
<U1096> <0>;<SHAN>;<BLANK>;<BLANK>   % Shan DIGIT SIX
<U0037> <7>;<BLANK>;<BLANK>;<BLANK>   % DIGIT SEVEN
<U1047> <7>;<MYANMAR>;<BLANK>;<BLANK>   % Myanmar DIGIT SEVEN
<U1097> <0>;<SHAN>;<BLANK>;<BLANK>   % Shan DIGIT SEVEN
<U0038> <8>;<BLANK>;<BLANK>;<BLANK>   % DIGIT EIGHT
<U1048> <8>;<MYANMAR>;<BLANK>;<BLANK>   % Myanmar DIGIT EIGHT
<U1098> <0>;<SHAN>;<BLANK>;<BLANK>   % Shan DIGIT EIGHT
<U0039> <9>;<BLANK>;<BLANK>;<BLANK>   % DIGIT NINE
<U1049> <9>;<MYANMAR>;<BLANK>;<BLANK>   % Myanmar DIGIT NINE
<U1099> <0>;<SHAN>;<BLANK>;<BLANK>   % Shan DIGIT NINE

% Latin alphabet
<U0041> <a>;<BLANK>;<BLANK>;<CAP>  % A
<U0061> <a>;<BLANK>;<BLANK>;<MIN>  % a
<U0042> <b>;<BLANK>;<BLANK>;<CAP>  % B
<U0062> <b>;<BLANK>;<BLANK>;<MIN>  % b
<U0043> <c>;<BLANK>;<BLANK>;<CAP>  % C
<U0063> <c>;<BLANK>;<BLANK>;<MIN>  % c
<U0044> <d>;<BLANK>;<BLANK>;<CAP>  % D
<U0064> <d>;<BLANK>;<BLANK>;<MIN>  % d
<U0045> <e>;<BLANK>;<BLANK>;<CAP>  % E
<U0065> <e>;<BLANK>;<BLANK>;<MIN>  % e
<U0046> <f>;<BLANK>;<BLANK>;<CAP>  % F
<U0066> <f>;<BLANK>;<BLANK>;<MIN>  % f
<U0047> <g>;<BLANK>;<BLANK>;<CAP>  % G
<U0067> <g>;<BLANK>;<BLANK>;<MIN>  % g
<U0048> <h>;<BLANK>;<BLANK>;<CAP>  % H
<U0068> <h>;<BLANK>;<BLANK>;<MIN>  % h
<U0049> <i>;<BLANK>;<BLANK>;<CAP>  % I
<U0069> <i>;<BLANK>;<BLANK>;<MIN>  % i
<U004A> <j>;<BLANK>;<BLANK>;<CAP>  % J
<U006A> <j>;<BLANK>;<BLANK>;<MIN>  % j
<U004B> <k>;<BLANK>;<BLANK>;<CAP>  % K
<U006B> <k>;<BLANK>;<BLANK>;<MIN>  % k
<U004C> <l>;<BLANK>;<BLANK>;<CAP>  % L
<U006C> <l>;<BLANK>;<BLANK>;<MIN>  % l
<U004D> <m>;<BLANK>;<BLANK>;<CAP>  % M
<U006D> <m>;<BLANK>;<BLANK>;<MIN>  % m
<U004E> <n>;<BLANK>;<BLANK>;<CAP>  % N
<U006E> <n>;<BLANK>;<BLANK>;<MIN>  % n
<U004F> <o>;<BLANK>;<BLANK>;<CAP>  % O
<U006F> <o>;<BLANK>;<BLANK>;<MIN>  % o
<U0050> <p>;<BLANK>;<BLANK>;<CAP>  % P
<U0070> <p>;<BLANK>;<BLANK>;<MIN>  % p
<U0051> <q>;<BLANK>;<BLANK>;<CAP>  % Q
<U0071> <q>;<BLANK>;<BLANK>;<MIN>  % q
<U0052> <r>;<BLANK>;<BLANK>;<CAP>  % R
<U0072> <r>;<BLANK>;<BLANK>;<MIN>  % r
<U0053> <s>;<BLANK>;<BLANK>;<CAP>  % S
<U0073> <s>;<BLANK>;<BLANK>;<MIN>  % s
<U0054> <t>;<BLANK>;<BLANK>;<CAP>  % T
<U0074> <t>;<BLANK>;<BLANK>;<MIN>  % t
<U0055> <u>;<BLANK>;<BLANK>;<CAP>  % U
<U0075> <u>;<BLANK>;<BLANK>;<MIN>  % u
<U0056> <v>;<BLANK>;<BLANK>;<CAP>  % V
<U0076> <v>;<BLANK>;<BLANK>;<MIN>  % v
<U0057> <w>;<BLANK>;<BLANK>;<CAP>  % W
<U0077> <w>;<BLANK>;<BLANK>;<MIN>  % w
<U0058> <x>;<BLANK>;<BLANK>;<CAP>  % X
<U0078> <x>;<BLANK>;<BLANK>;<MIN>  % x
<U0059> <y>;<BLANK>;<BLANK>;<CAP>  % Y
<U0079> <y>;<BLANK>;<BLANK>;<MIN>  % y
<U005A> <z>;<BLANK>;<BLANK>;<CAP>  % Z
<U007A> <z>;<BLANK>;<BLANK>;<MIN>  % z

EOT

# define order

# for ($y = 1; $y<=$#yrwh; $y++) # loop over yrwh medials
# {
#     printf("<MMYRWH%02d> \"<CSMMYRWH%02d>\";IGNORE;IGNORE;IGNORE\n",$y,$y);
# }


# vowels with killed consonant
for ($m = 0; $m<=$#killed; $m++) # loop over other medials
{
    $killer = $killed[$m];
    $killer =~ s/[<>U]//g;
    for ($v = 1; $v<=$#myVowels; $v++)
    {
        $vowel = $myVowels[$v];
        $vowel =~ s/[<>U]//g;
        $ce = sprintf("<MMV%sK%sA>",$vowel,$killer);
        $cw = sprintf("\"<CSMMCK%s><CSMMV%s>\"",$killer,$vowel);
        
        if ($killed[$m] eq "<U1019>" && ($vowel eq "102F" || $vowel eq "102D")) # upper dot
	{
	    printf("<MMV%sK1019A> \"<CSMMCK%s1019>\";\"<KILLED>\";<BLANK>;<BLANK>\n", $vowel,$vowel);
	    printf("<MMV%sK1019B> \"<CSMMCK%s1019>\";\"<STACK>\";<BLANK>;<BLANK>\n", $vowel,$vowel);
	    printf("<MMV%sK1019C> \"<CSMMCK%s1036>\";\"<BLANK>\";<BLANK>;<BLANK>\n", $vowel,$vowel);
	    printf("<MMV%sK10191037A> \"<CSMMCK%s10191037><CSMMV>\";\"<KILLED>\";<BLANK>;<BLANK>\n", $vowel,$vowel);
	    printf("<MMV%sK10191037A2> \"<CSMMCK%s10191037><CSMMV>\";\"<KILLED>\";<BLANK>;<BLANK>\n", $vowel,$vowel);
	    printf("<MMV%sK10191037C> \"<CSMMCK%s10361037><CSMMV>\";\"<BLANK>\";<BLANK>;<BLANK>\n", $vowel,$vowel);
            printf("<MMV%sK10191038A> \"<CSMMCK%s10191038><CSMMV>\";\"<KILLED>\";<BLANK>;<BLANK>\n", $vowel,$vowel);
            printf("<MMV%sK10191038C> \"<CSMMCK%s10361038><CSMMV>\";\"<BLANK>\";<BLANK>;<BLANK>\n", $vowel,$vowel);
	}
        else
        {
            printf("%s %s;\"<KILLED>\";<BLANK>;<BLANK>\n",$ce,$cw);
            $ce = sprintf("<MMV%sK%sB>",$vowel,$killer);
            printf("%s %s;\"<STACK>\";<BLANK>;<BLANK>\n",$ce,$cw);
            if (exists($equivalentVowels{$myVowels[$v]}))
            {
                $equiv = $equivalentVowels{$myVowels[$v]};
                for ($i = 0; $i <= $#{$equiv}; $i++)
                {
                    $ce = sprintf("<MMV%sALT%dK%sA>",$vowel,$i,$killer);
                    printf("%s %s;\"<KILLED>\";<BLANK>;<ALT>\n",$ce,$cw);
                    $ce = sprintf("<MMV%sALT%dK%sB>",$vowel,$i,$killer);
                    printf("%s %s;\"<STACK>\";<BLANK>;<ALT>\n",$ce,$cw);
                }
            }
            if ($killed[$m] eq "<U101E>") # great sa
            {
                $ce = sprintf("<MMV%sK%sC>",$vowel,$killer);
                $cw = sprintf("\"<CSMMCK%s><CSMMV%s><U101E>\"",$killer,$vowel);
                printf("%s %s;\"<STACK>\";<BLANK>;<BLANK>\n",$ce,$cw);
            }
        }
    }
}

# stand alone killed consonants
for ($m = 0; $m<=$#killed; $m++) # loop over other medials
{
    $killer = $killed[$m];
    $killer =~ s/[<>U]//g;
    printf("<MMK%sA> <CSMMCK%s>;<STACK>;<BLANK>;<BLANK>\n",$killer,$killer);
    printf("<MMK%sB> <CSMMCK%s>;<KILLED>;<BLANK>;<BLANK>\n",$killer,$killer);
}

#for ($c = 0; $c<=$LAST_CONSONANT; $c++) # loop over consonants
#{
# shouldn't need the medials to be combined now they have their own codes
#    printf("<U10%02X> <CSMMC%02d>;IGNORE;IGNORE;IGNORE\n",$c,$c);
#}
for ($c = 0; $c <= $#consonants; $c++)
{
    $cons = $consonants[$c];
    $cons =~ s/[<U>]//g;
    printf("%s <CSMMC%s>;<BLANK>;<BLANK>;<BLANK>\n",$consonants[$c],$cons);
}

for ($y = 1; $y<=$#yrwh; $y++) # loop over yrwh medials
{
    $med = $yrwh[$y];
    $med =~ s/[<U>]//g;
    printf("<MMYRWH%s> \"<CSMMYRWH%s>\";<BLANK>;<BLANK>;<BLANK>\n",$med,$med);
}

# should the symbols really go here?
#printf("<U104C> <CSMMS01>;IGNORE;IGNORE;IGNORE\n");
#printf("<U104D> <CSMMS02>;IGNORE;IGNORE;IGNORE\n");
#printf("<U104E> <CSMMS03>;IGNORE;IGNORE;IGNORE\n");
#printf("<U104F> <CSMMS04>;IGNORE;IGNORE;IGNORE\n");


# vowels without killed consonants
for ($v = 1; $v<=$#vowels; $v++)
{
    $vowel = $vowels[$v];
    $vowel =~ s/[<>U]//g;
    $vv = sprintf("<MMV%s>",$vowel);
    $vw = sprintf("<CSMMV%s>",$vowel);
    
    printf("%s %s;<BLANK>;<BLANK>;<BLANK>\n",$vv,$vw);
    if (exists($equivalentVowels{$vowels[$v]}))
    {
        $equiv = $equivalentVowels{$vowels[$v]};
        for ($i = 0; $i <= $#{$equiv}; $i++)
        {
            #print STDERR "Equiv" . $equiv->[$i] . "\n";
            $vv = sprintf("<MMV%sALT%d>", $vowel, $i);
            printf("%s %s;<BLANK>;<BLANK>;<ALT>\n",$vv,$vw);
        }
    }
}

for ($t = 1; $t<=$#tones; $t++) # loop over tones
{
    $tone = $tones[$t];
    $tone =~ s/[<>U]//g;
    printf("<MMT%s> <CSMMT%s>;IGNORE;IGNORE;IGNORE\n",$tone,$tone);
}

# this determines whether stacked or unstacked forms are sorted first
#printf("<U200C> IGNORE;<U200C>;IGNORE;IGNORE\n");

# great sa
printf("<U103F> \"<CSMMCK101E><CSMMC101E>\";<STACK>;<BLANK>;<BLANK>\n");


#<MMC1021V102FK1036> "<CSMMC1021><CSMMCK102F1036>";<BLANK>;<BLANK>;<BLANK>

# the independent vowels
# <MMC101AV102FK1036> is a special case because otherwise the split of
# 1021 and 102F 1036 collation elements causes an incorrect order at the 
# secondary level
print << 'EOT';
<U1023> "<CSMMC1021><CSMMV102D>";<MYIV>;<MYIV>;<MYIV> % i vowel
<U1024> "<CSMMC1021><CSMMV102E>";<MYIV>;<MYIV>;<MYIV> % ii vowel
<U1025> "<CSMMC1021><CSMMV102F>";<MYIV>;<MYIV>;<MYIV> % u
<U1026> "<CSMMC1021><CSMMV1030>";<MYIV>;<MYIV>;<MYIV> % uu
<U1027> "<CSMMC1021><CSMMV1031>";<MYANMAR>;<MYIV>;<MYIV> % e
<U1028> "<CSMMC1021><CSMMV1031>";<MON>;<MYIV>;<MYIV> % e
<U1029> "<CSMMC1021><CSMMV1031102C>";<MYIV>;<MYIV>;<MYIV> % aww-high
<U102A> "<CSMMC1021><CSMMV1031102C103A>";<MYIV>;<MYIV>;<MYIV> % aww-low

<I1023K1005A> "<CSMMC1021><CSMMCK1005><CSMMV102D>";<STACK>;<MYIV>;<MYIV>
<I1023K1005B> "<CSMMC1021><CSMMCK1005><CSMMV102D>";<KILLED>;<MYIV>;<MYIV>
<I1023K100BA> "<CSMMC1021><CSMMCK100B><CSMMV102D>";<STACK>;<MYIV>;<MYIV>
<I1023K100BB> "<CSMMC1021><CSMMCK100B><CSMMV102D>";<KILLED>;<MYIV>;<MYIV>
<I1023K1010A> "<CSMMC1021><CSMMCK1010><CSMMV102D>";<STACK>;<MYIV>;<MYIV>
<I1023K1010B> "<CSMMC1021><CSMMCK1010><CSMMV102D>";<KILLED>;<MYIV>;<MYIV>
<I1023K1012A> "<CSMMC1021><CSMMCK1012><CSMMV102D>";<STACK>;<MYIV>;<MYIV>
<I1023K1012B> "<CSMMC1021><CSMMCK1012><CSMMV102D>";<KILLED>;<MYIV>;<MYIV>
<I1023K1014A> "<CSMMC1021><CSMMCK1014><CSMMV102D>";<STACK>;<MYIV>;<MYIV>
<I1023K1014B> "<CSMMC1021><CSMMCK1014><CSMMV102D>";<KILLED>;<MYIV>;<MYIV>
<I1023K1019A> "<CSMMC1021><CSMMCK102D1019>";<STACK>;<MYIV>;<MYIV>
<I1023K1019B> "<CSMMC1021><CSMMCK102D1019>";<KILLED>;<MYIV>;<MYIV>
<I1023K101E> "<CSMMC1021><CSMMCK101E><CSMMV102D><CSMMC101E>";<STACK>;<MYIV>;<MYIV>
<I1025K1000A> "<CSMMC1021><CSMMCK1000><CSMMV102F>";<STACK>;<MYIV>;<MYIV>
<I1025K1000B> "<CSMMC1021><CSMMCK1000><CSMMV102F>";<KILLED>;<MYIV>;<MYIV>
<I1025K1005A> "<CSMMC1021><CSMMCK1005><CSMMV102F>";<STACK>;<MYIV>;<MYIV>
<I1025K1005B> "<CSMMC1021><CSMMCK1005><CSMMV102F>";<KILLED>;<MYIV>;<MYIV>
<I1025K100AA> "<CSMMC1021><CSMMCK100A><CSMMV102F>";<STACK>;<MYIV>;<MYIV>
<I1025K100AB> "<CSMMC1021><CSMMCK100A><CSMMV102F>";<KILLED>;<MYIV>;<MYIV>
<I1025K100FA> "<CSMMC1021><CSMMCK100F><CSMMV102F>";<STACK>;<MYIV>;<MYIV>
<I1025K100FB> "<CSMMC1021><CSMMCK100F><CSMMV102F>";<KILLED>;<MYIV>;<MYIV>
<I1025K1010A> "<CSMMC1021><CSMMCK1010><CSMMV102F>";<STACK>;<MYIV>;<MYIV>
<I1025K1010B> "<CSMMC1021><CSMMCK1010><CSMMV102F>";<KILLED>;<MYIV>;<MYIV>
<I1025K1012A> "<CSMMC1021><CSMMCK1012><CSMMV102F>";<STACK>;<MYIV>;<MYIV>
<I1025K1012B> "<CSMMC1021><CSMMCK1012><CSMMV102F>";<KILLED>;<MYIV>;<MYIV>
<I1025K1014A> "<CSMMC1021><CSMMCK1014><CSMMV102F>";<STACK>;<MYIV>;<MYIV>
<I1025K1014B> "<CSMMC1021><CSMMCK1014><CSMMV102F>";<KILLED>;<MYIV>;<MYIV>
<I1025K1015A> "<CSMMC1021><CSMMCK1015><CSMMV102F>";<STACK>;<MYIV>;<MYIV>
<I1025K1015B> "<CSMMC1021><CSMMCK1015><CSMMV102F>";<KILLED>;<MYIV>;<MYIV>
<I1025K1019A> "<CSMMC1021><CSMMCK102F1019>";<STACK>;<MYIV>;<MYIV>
<I1025K1019B> "<CSMMC1021><CSMMCK102F1019>";<KILLED>;<MYIV>;<MYIV>
<I1025K1036> "<CSMMC1021><CSMMCK102F1036>";<KILLED>;<MYIV>;<MYIV>
<I1025K101E> "<CSMMC1021><CSMMCK101E><CSMMV102F><CSMMC101E>";<STACK>;<MYIV>;<MYIV>
<I1027K100AA> "<CSMMC1021><CSMMCK100A><CSMMV1031>";<STACK>;<MYIV>;<MYIV>
<I1027K100AB> "<CSMMC1021><CSMMCK100A><CSMMV1031>";<KILLED>;<MYIV>;<MYIV>
<I1029K100BA> "<CSMMC1021><CSMMCK100B><CSMMV1031102C>";<STACK>;<MYIV>;<MYIV>
<I1029K100BB> "<CSMMC1021><CSMMCK100B><CSMMV1031102C>";<KILLED>;<MYIV>;<MYIV>
<I1029K1010A> "<CSMMC1021><CSMMCK1010><CSMMV1031102C>";<STACK>;<MYIV>;<MYIV>
<I1029K1010B> "<CSMMC1021><CSMMCK1010><CSMMV1031102C>";<KILLED>;<MYIV>;<MYIV>
<I10291031102CK1004A> "<CSMMC1021><CSMMCK1004><CSMMV1031102C>";<STACK>;<MYIV>;<MYIV>
<I10291031102CK1004B> "<CSMMC1021><CSMMCK1004><CSMMV1031102C>";<STACK>;<MYIV>;<MYIV>

<Man> "<CSMMC101A><CSMMCK1000><CSMMV1031102C><CSMMC1000><CSMMYRWH103B><CSMMV102C><CSMMT1037>";<BLANK>;<BLANK>;<BLANK>
<FirstPerson> "<CSMMC1000><CSMMYRWH103B103D><CSMMCK1014><CSMMC1014><CSMMCK1015><CSMMV102F>";<BLANK>;<BLANK>;<BLANK>
<RightPali> "<CSMMC101C><CSMMCK1000><CSMMC101A><CSMMV102C>";<ALT>;<BLANK>;<BLANK>
<Daughter> "<CSMMC101E><CSMMC1019><CSMMV102E>";<ALT>;<BLANK>;<BLANK>
<Rice> "<CSMMC1011><CSMMC1019><CSMMCK1004><CSMMT1038>";<ALT>;<BLANK>;<BLANK>
<Tea> "<CSMMC101C><CSMMCK1000><CSMMC1018><CSMMCK1000>";<ALT>;<BLANK>;<BLANK>

<U104C> "<CSMMC1014><CSMMYRWH103E><CSMMCK1000><CSMMV102D102F>";<KILLED>;<BLANK>;<BLANK>
<U104D> "<CSMMC101B><CSMMYRWH103D><CSMMV1031><CSMMT1037>";<KILLED>;<BLANK>;<BLANK>
<U104E> "<CSMMC101C><CSMMCK100A><MMT1038><CSMMC1000><CSMMCK1004><CSMMV1031102C><MMT1038>";<ALT>;<BLANK>;<BLANK>
<U104F> "<CSMMC1021><CSMMV102D>";<ALT>;<BLANK>;<BLANK>

EOT


# end file
print "order_end\n";
print "END LC_COLLATE\n";
print "% --- End of generated section\n";
