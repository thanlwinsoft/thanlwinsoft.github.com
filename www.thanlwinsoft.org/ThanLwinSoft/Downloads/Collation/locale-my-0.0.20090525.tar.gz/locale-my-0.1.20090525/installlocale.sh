#!/bin/bash
echo "Install Myanmar locales"
# For RH & Fedora locales are built in below path
LOCALEDIR=/usr/lib/locale
#rm -f /tmp/UTF-8
#cp /usr/share/i18n/charmaps/UTF-8.gz /tmp
#gzip -d /tmp/UTF-8.gz
perl genMyCollate.pl > myCollate
#cat my_MM_head myCollate my_MM_tail > my_MM
cp iso14651_t1_common /usr/share/i18n/locales/
cat my_MM_head my_MM_collate my_MM_tail > my_MM
# -c forces output even if warnings
# -v gives verbose output
localedef -c -i my_MM -f UTF-8_uni5.1 $LOCALEDIR/my_MM.utf8
#rm -f /tmp/UTF-8
echo "Locale Installation Done"
