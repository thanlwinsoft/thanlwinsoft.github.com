/* 
Testing for Myanmar Unicode Support

Copyright 2005 www.ThanLwinsoft.org
This work is licensed under a Creative Commons Attribution-ShareAlike 2.5 License.
http://creativecommons.org/licenses/by-sa/2.5/

You are free to modify this code to meet your requirements, as specified in the above 
license. Please include a link to www.thanlwinsoft.org on your website.

A simple detection algorithm based on the fact that a Myanmar Unicode enabled browser 
renders U+1000 U+1039 U+1000 with the 2 consonants stacked on top of each other. 
It should therefore have half the width of U+1000 U+1000.
A non-compliant browser will not interpret the 
U+1039 correctly and so renders it as 2 consonants of twice the width. 
If a Myanmar font is not installed, it will actually have 3 times the width.
Obviously, there are lots of possible variations for this test. 

Include these 2 strings in your page:
<span class="myUniTest" id="myWidth2">ကက</span>
<span class="myUniTest" id="myWidth1">က္က</span>

You can append the 2 test spans to any text in your page where it will not get in the way.
The style class makes it invisible by setting the color to be the same as the background. 

Note: the <span>s must be before the script, so they are available as the page loads. 
*/

// tweak these strings to meet your requirements
var iconPath = "";
var mySupported = "<p class='myGood'>Congratulations your browser is Myanmar Unicode enabled! <br />" +
"<span class='myText'>မိတ္‌\u200cဆ္ဝေရဲ့</span> web browser <span class='myText'>က မ္ရန္\u200c‌မာ</span>" +
" Unicode <span class='myText'>ကုိ သုံးလုိ့ ရတဲ့အတ္ဝက္‌ ဝမ္\u200c‌းမ္ရောက္\u200c‌ပာတယ္‌\u200c။</span></p>";
var myUnsupported = "<div class='myUnicodeTestFailed'>" +
"<p class='myWarning'>Warning: This site uses the <a href='http://www.unicode.org' class='myFirefoxLink'>International Unicode Standard</a> to store and display Myanmar/Burmese text. " +
"Please upgrade to a browser with Myanmar Unicode support: " +
"<ol><li>Download a Graphite enabled Myanmar Unicode font such as " +
"<a href='http://sila.mozdev.org/grFirefox.html' class='myFirefoxLink'>Padauk</a> and copy it into your C:\\Windows\\Fonts directory.</li>" +
"<li>Install <a href='http://sila.mozdev.org/grFirefox.html' class='myFirefoxLink'>Graphite enabled Firefox</a> (Normal Mozilla Firefox will not work correctly).</li></ol></p>" +
// images for the Burmese translation, since we know the browser can't render it.
"<p class='myTextMsg'><img src='" + iconPath + "myNoUnicode0.png' /><br />" +
"<a href='http://sila.mozdev.org/grFirefox.html'><img src='" + iconPath + "myNoUnicode1.png' /></a><br />" +
"<a href='http://sila.mozdev.org/grFirefox.html'><img src='" + iconPath +"myNoUnicode2.png' /></a></p>" +
"<p><span class='myThanLwin'>This site uses <a href='http://www.thanlwinsoft.org' class='myFirefoxLink'>Myanmar Unicode technology from ThanLwinSoft.org</a></span></p></div>" ;

/**
* Test the browser for Myanmar Unicode Support.
* Call this function from inside a script element inside the body of your web page.
* @return true if the browser has Myanmar Unicode support.
*/
function myUnicodeCheck()
{
var myEnabled = false;
var myW2 = document.getElementById('myWidth2');
var myW1 = document.getElementById('myWidth1');
var myW1Width = 0;
var myW2Width = 0;
if (myW1 && myW2)
{
    myW1Width = myW1.offsetWidth;
    myW2Width = myW2.offsetWidth;
    // what does IE use for width?
    if (myW1Width == undefined) myW1Width = myW1.width;
    if (myW2Width == undefined) myW2Width = myW2.width;
}
else
{
  return false;
}
// debug line - you will probably not need this unless you have trouble
//document.writeln('width1=' + myW1Width + ' width2=' + myW2Width + '<br/>');
// the width of w2 may not always be exactly twice w1 depending on the font
// and rounding errors. However it should be safe to say that w1's width should be 
// much less than 3/4 of w2's width.
if (myW1Width >= 0.75 * myW2Width || myW1Width == undefined)
{
    document.writeln(myUnsupported);
}
else 
{
    if (mySupported.length > 0)
    {
        document.writeln(mySupported);
    }
    myEnabled = true;
} 
return myEnabled;
}
