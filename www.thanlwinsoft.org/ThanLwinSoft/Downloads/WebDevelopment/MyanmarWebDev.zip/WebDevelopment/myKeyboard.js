/*
Copyright 2005 ThanLwinSoft.org

You are free to use this on your website and modify it 
subject to a Creative Commons license. 
However, please add a link to www.thanlwinsoft.org 
on every page that uses this script. For more info
and contact details see www.thanlwinsoft.org.

This copyright statement must not be removed.

Version:       0.1
Author:        Keith Stribley (KRS)
Contributors:  

Change History:
08-07-2005  KRS  Initial Version

*/
// you may need to override the inputId value to match the id on your 
// input box. You can do this inside script tags after you have
// included this script.
var inputId = "textInput";

/**
* The algorithm used here uses the syllable structure from Unicode 4
* Chapter 10.3 and UTN 11. 
* The only difference is that medial ya and ra are combined
* since they never occur together in modern Burmese.
* 
*/
// globals
var consMode = 0;
var numLevels = 14;
var textString = "";
var lastTokenLength = 1; // used by getCharOrder()
var currentSyllable = new Array("", "", "", "", "", "", "", "",
                          "", "", "", "", "", "", "");
var stackableCons = new Array('u1000', 'u1001', 'u1002', 'u1003', 
                        'u1005', 'u1006', 'u1007', 'u1008', 
                        'u100b', 'u100c', 'u100d', 'u100f',
                        'u1010', 'u1011', 'u1012', 'u1013', 'u1014',
                        'u1015', 'u1016', 'u1017', 'u1018', 'u1019',
                        'u101c', 'u101e', 'u1021');
var nonStackableCons = new Array('u1004', 'u1009', 'u100a', 'u100e', 
                            'u101a', 'u101b',
                            'u101d', 'u101f', 'u1020');
// consonant nodes handled separately                            
var positionNodes = new Array(['kinzi'], "", "", ['medYa', 'medRa'], 
                          ['medWa'], ['medHa'],
                          ['u1031'], ['u102f', 'u1030'], 
                          ['u102d', 'u102e', 'u1032'], 
                          ['u102c'], ['u1036'], ['killer'], 
                          ['u1037'], ['u1038']); 
 
/** empty method to allow extension */                         
function afterKey()
{
}
/**
* Looks for the text held in the syllable array at the end of the 
* specified input element
* @param inputElement handle to input Element
* @internal
*/
function findOldText(inputElement)
{
  var oldText = inputElement.value;
  // strip off current syllable
  var oldSyllable = syllableToString();
  var oldIndex = oldText.lastIndexOf(oldSyllable);
  if (oldIndex > -1 && (oldIndex + oldSyllable.length == oldText.length))
  {
    oldText = oldText.substring(0, oldIndex);
  }
  else // currentSyllable and input box are out of sync
  {
    oldText = findEndSyllable(oldText, false);
  }
  return oldText;
}

/**
* types the character clicked upon and appends it to the syllable
* array. Usually disables all other characters representing
* the same position in the syllable to prevent invalid sequences
* unless the character (visually) represents the start of a syllable.
* @param charValue unicode code points representing character
* @param predefined position index within syllable
*/
function typeChar(charValue, pos)
{
  var characters = charValue;
  var inputElement = document.getElementById(inputId);
  var oldText = findOldText(inputElement);
  
  if (pos == 1)
  {
    if (consMode == 0)
    {
      if (currentSyllable[pos] != "")
      {
        oldText = oldText + syllableToString();
        resetSyllable();
      }
      currentSyllable[pos] = charValue;
      //window.status = currentSyllable[pos];
    }
    else
    {
      currentSyllable[2] = "\u1039" + charValue;
      toggleStack();
      disable('stack');
      disable('kinzi');
    }
  }
  else if (pos == 0)
  {
    currentSyllable[pos] = charValue;
    disable('stack');
    disable('kinzi');
  }
  else
  {
    // special handling for medials with 1004
    if (currentSyllable[1] == '\u1004' && pos < 6)
    {
      characters = '\u200d' + charValue;
    }
    if (pos == 6 && currentSyllable[1] != "")
    {
      oldText = oldText + syllableToString();
      resetSyllable();
    }
    currentSyllable[pos] = characters;
    var ids = positionNodes[pos];
    for (var j = 0; j < ids.length; j++)
    {
      disable(ids[j]);
    }
  }
  inputElement.value = oldText + syllableToString();
  window.status = inputElement.value + " Syllable = " + syllableToString() + 
    " " + currentSyllable.length;
  afterKey();
}

/**
* Deletes the last character typed by the user at the end of the
* string. This may actually consist of several unicode code
* points e.g. for medials.
*/
function deleteChar()
{
  var inputElement = document.getElementById(inputId);
  var oldText = findOldText(inputElement);
  var deleted = false;
  var lastOfSyllable = false;
  for (var i = currentSyllable.length - 1; i>=0; i--)
  {
    if (currentSyllable[i] != "")
    {
      currentSyllable[i] = "";
      var ids = positionNodes[i];
      for (var j = 0; j < ids.length; j++)
      {
        enable(ids[j]);
      }   
      deleted = true;
      if (i == 0 || i == 1 && currentSyllable[0] == "")
      {
        lastOfSyllable = true;
      }
      break;
    }
  }
  if (!deleted || lastOfSyllable)
  {
    // need to update oldText and move to previous syllable
    oldText = findEndSyllable(oldText, !deleted);
  }
  inputElement.value = oldText + syllableToString();
  afterKey();
}

/**
* @param oldText to find last syllabe of
* @param forDelete boolean flag that says whether the first 
* @param component of the last syllable should be deleted
* @return start of oldText which is not in the last syllable
* @internal
*/
function findEndSyllable(oldText, forDelete)
{
  var deleted = true;
  if (forDelete) deleted = false;
  if (oldText.length > 0)
  {
    var charIndex = oldText.length - 1;
    resetSyllable();
    var prevOrder = numLevels;
    while (charIndex > -1)
    {
      var order = getCharOrder(oldText, charIndex);
      charIndex -= lastTokenLength;
      if ((prevOrder == 1 && order == 0) ||
          (prevOrder > 1))
      {
        // need to delete the first syllable we find
        if (deleted)
        {
          currentSyllable[order] = oldText.substr(charIndex + 1,
                                                lastTokenLength);
          var ids = positionNodes[order];
          for (var j = 0; j < ids.length; j++)
          {
            disable(ids[j]);
          }
          if (order == 2 || order == 0) 
          {
            disable('stack');
            if (consMode == 1) toggleStack(); 
          }
          prevOrder = order;
        }
        else
        {
          deleted = true; 
          prevOrder = order;
        }                                       
      }                
      else
      {
        charIndex += lastTokenLength;
        break;
      }                       
      if (order == 0) break;                          
    }
  }
  return oldText.substring(0, charIndex + 1);
}

/**
* This assumes that the parsing is being done backwards
* checks to see if the previos character is akiller, if so
* the order is set to killOrder otherwise 1 is returned.
* @param theText test string from input box
* @param charIndex to test
* @param killOrder order if there is a killer before
* @return index of character
* @internal
*/
function setOrderIfPrevious1039(theText, charIndex, killOrder)
{
  var order = 1;
  if (charIndex > 0)
  {
    var previous = theText.substring(charIndex - 1, charIndex);
    if (previous == '\u1039')
    {
      order = killOrder;
      lastTokenLength = 2;
    }
    // now check the kiler doesn't belong to Kinzi if so the 
    // order is still 1
    if (charIndex > 1)
    {
      previous = theText.substring(charIndex - 2, charIndex - 1);
      if (previous == '\u1004')
      {
        order = 1;
        lastTokenLength = 1;
      }
      // if the base is 1004 then a medial will have an extra
      // 200d to prevent kinzi appearing
      else if (previous == '\u200d') 
      {
        lastTokenLength = 3;
      }
    }
  }
  return order;
}

/**
* This assumes that the parsing is being done backwards
* @param theText test string from input box
* @param charIndex to test
* @return index of character
* @internal
*/
function getCharOrder(theText, charIndex)
{
  var order = 1;
  var theChar = theText.substring(charIndex, charIndex + 1);
  lastTokenLength = 1;
  switch (theChar)
  {
    // kinzi is handled later
    case '\u1004':
      order =1;
      break;
    // stackable consonants
    case '\u1000':
    case '\u1001':
    case '\u1002':
    case '\u1003':
    case '\u1005':
    case '\u1006':
    case '\u1007':
    case '\u1008':
    case '\u100b':
    case '\u100c':
    case '\u100d':
    case '\u100f':
    case '\u1010':
    case '\u1011':
    case '\u1012':
    case '\u1013':
    case '\u1014':
    case '\u1015':
    case '\u1016':
    case '\u1017':
    case '\u1018':
    case '\u1019':
    case '\u101c':
    case '\u101e':
    case '\u1021':
      order = setOrderIfPrevious1039(theText, charIndex, 2);
      break;
    case '\u101a':
    case '\u101b':
      order = setOrderIfPrevious1039(theText, charIndex, 3);
      break;
    case '\u101d':
      order = setOrderIfPrevious1039(theText, charIndex, 4);
      break;
    case '\u101f':
      order = setOrderIfPrevious1039(theText, charIndex, 5);
      break;
    case '\u1031':
      order = 6;
      break;
    case '\u102f':
    case '\u1030':
      order = 7; 
      break;
    case '\u102d':
    case '\u102e':
    case '\u1032':
      order = 8;
      break;
    case '\u102c':
      order = 9;
      break;
    case '\u1036':
      order = 10;
      break;
    case '\u200c':
      order = setOrderIfPrevious1039(theText, charIndex, 11);
      break;
    case '\u1037':
      order = 12;
      break;
    case '\u1038':
      order = 13;
      break;
    case '\u1039':
      order = 1;
      // we expect this to only be seen if the previous character is Kinzi
      if (charIndex > 0)
      {
        var previous = theText.substring(charIndex - 1, charIndex);
        if (previous == '\u1004')
        {
          order = 0;
          lastTokenLength = 2;
        }  
      }
      break;
    default:
      order = 1;
  }
  return order;
}


/**
* Converts the stored syllable aray into a string
* @internal
*/
function syllableToString()
{
  var text = "";
  for (var i = 0; i < currentSyllable.length; i++)
  {
    if (i == 1 && currentSyllable[i] == "")
    {
      text = text + '\u25cc';
    }
    else text = text + currentSyllable[i];
  }
  // check for empty string
  if (text == "\u25cc") text = "";
  return text;
}

/**
* hides the element with the given id
* will silently fail if id does not exist
* @param id of element
*/
function disable(id)
{
  var element = document.getElementById(id);
  element.style.display = "none";
}

/**
*
* hides the element with the given id
* will silently fail if id does not exist
* @param id of element
*/
function enable(id)
{
  var element = document.getElementById(id);
  element.style.display = "";
}

/**
* creates an empty syllable array
* @internal
*/
function resetSyllable()
{
  currentSyllable = new Array("", "", "", "", "", "", "", 
                        "", "", "", "", "", "", "", "");
  enable('stack');
  enable('kinzi');
  for (var i = 3; i < numLevels; i++)
  {
    var ids = positionNodes[i];
    for (var j = 0; j < ids.length; j++)
    {
      enable(ids[j]);
    }
  }
}


/**
* toggles display of normal or stacked consonant links
*/
function toggleStack()
{
  if (consMode == 0)
  {
    consMode = 1;
    for (var i = 0; i < stackableCons.length; i++)
    {
      var element = document.getElementById(stackableCons[i]);
      var text = new String(element.firstChild.nodeValue);
      var u25cc = document.createTextNode('\u25cc\u1039' + text);
      element.replaceChild(u25cc, element.firstChild);
    }
    for (var i = 0; i < nonStackableCons.length; i++)
    {
      var element = document.getElementById(nonStackableCons[i]);
      element.style.display = "none";
    }
  }
  else
  {
    consMode = 0;
    for (var i = 0; i < stackableCons.length; i++)
    {
      var element = document.getElementById(stackableCons[i]);
      var text = new String(element.firstChild.nodeValue);
      var removed = text.replace("\u25cc\u1039", "");
      var no25cc = document.createTextNode(removed);
      element.replaceChild(no25cc, element.firstChild);
    }
    for (var i = 0; i < nonStackableCons.length; i++)
    {
      var element = document.getElementById(nonStackableCons[i]);
      element.style.display = "";
    }
  }
}
/**
* hides the keyboard
*/
function hideKeyboard()
{
  disable('keyboard');
}

/**
* toggles display of the keyboard on or off
*/
function toggleKeyboard()
{
  var keyboard = document.getElementById('keyboard');
  if (keyboard.style.display == "none")
  {
    keyboard.style.display = ""; 
  }
  else
  {
    keyboard.style.display = "none";
  }
}
