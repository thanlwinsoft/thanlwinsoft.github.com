Burmese+Graphite-in-OO

The examples show some slight rendering problems without graphite with the sequence 1004 103A 1039 (looks like an
inverted 3 above the consonants). There are also rendering errors with the version of Doulos used here
which doesn't have OT tables. With the graphite enabled version these errors are fixed.

DoulosFeaturesCalc/Draw/Impress/Writer

Each of these examples demonstrate features. Each line has slightly different rendering according to the
features, as described in the individual files. Without graphite support the lines with the features 
appended to the font name are shown with a fallback font.

ipa test

The IPA example file shows graphite being used to stack diacritics neatly on top of each other. The test
font doesn't contain graphite tables, so they are all rendered on top of each other without graphite support.

Nko test text
This is a RTL example. Without graphite support the characters do not have a line joining them up on the
baseline.

rtlFallbackTests
This example tests some fallback examples. The Scheherazade font used in the test has had the OT
tables removed, so the shaping only occurs with graphite.

