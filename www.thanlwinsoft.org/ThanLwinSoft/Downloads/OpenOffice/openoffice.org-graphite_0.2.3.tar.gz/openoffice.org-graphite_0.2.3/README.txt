Graphite Extension for OpenOffice.org

The Graphite Extension to OpenOffice provides an Option Page which allows
Graphite to be enabled and disabled. This actually modifies the
SAL_DISABLE_GRAPHITE environment variable which is set in ~/.profile on Linux
and HKCU/environment in the Windows registry.
The extension also adds an option to the context menu to allow Graphite
features to be graphically selected using a Dialog. This saves users from
having to know the individual feature IDs from the font.

