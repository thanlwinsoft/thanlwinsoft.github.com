Graphite JNI Readme
===================

The Graphite JNI provides a basic interface to the graphite rendering library 
from Java. Currently only rendering and cursor tracking have been tested. 
Line breaking is not yet implemented.

Building - Java
---------------
Ant (http://ant.apache.org/) is used to build the Java. Make sure that you have
ant configured and on your path with ANT_HOME set correctly.
You also need to have JAVA_HOME set to a 1.5 or later JDK. 
If you want to use the Swing Graphite Look and Feel then you 
must be using a Sun JDK, since it is implemented using the Sun proprietary 
StandardGlyphVector class.

The default ant build should be sufficient:

ant

To force a rebuild use 

ant clean
ant

The graphite-0.0.1.jar and graphite-swing-0.0.1.jar files are placed in the 
build subdirectory. If you don't have a Sun JDK, then only graphite-0.0.1.jar
will be built.

Native library
--------------

You must have the JAVA_HOME environment variable set to the Java Development 
Kit directory before you compile the library.

Building on Windows
-------------------

If you have MS Visual Studio installed, then you can compile the windows 
library from the console using:

vcvars32.bat
nmake -f makefile.vc

The dll will be placed in the Release directory.

Building on Linux
-----------------

You can build the C++/C part of the wrapper using automake tools:

autoreconf -i
./configure --enable-final
make
make install

Using the GraphiteJNI
---------------------

The easiest way to enable Graphite rendering is to use the GrLookAndFeel.

You can either do this as one of the first lines in your main function:

UIManager.addAuxiliaryLookAndFeel( new GrLookAndFeel());

If you don't have access to the source you can use the 
-Dswing.auxiliarylaf=org.sil.graphite.ui.GrLookAndFeel
option when you run java assuming that 
graphite-0.0.1.jar and graphite-swing-0.0.1.jar are on your class path.

You can try the example (which assumes that you have the Padauk Graphite font
installed). 

java -jar graphite-swing-0.0.1.jar

The Graphite native library graphitejni.dll (Windows) or libgraphite.so (Linux)
must be on the System path on windows or the library path on linux. 
You could also copy it into the platform specific directory under 
$JAVA_HOME/jre/lib.

The Graphite code will only be activated for graphite fonts. At the moment, the
implementation is incomplete and probably slow. Several widgets are actually 
painted twice - once using the default rendering and then over painted with 
graphite. This is because it is difficult to integrate the graphite library at
a low enough level to prevent this. 

JTextArea does not currently render properly with Graphite - please use a 
JTextPane instead. Rarely used formatting parameters on widgets may well not be
rendered correctly. If not, please create a simple example that shows the 
problem and report it to the silgraphite developers list or fix it yourself 
and submit a patch!

